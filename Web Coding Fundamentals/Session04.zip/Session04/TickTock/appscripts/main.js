require(
    [],
    function () {
            
        console.log("yo, I'm alive!");

        var paper = new Raphael(document.getElementById("mySVGCanvas"));
        // Find get paper dimensions
        var dimX = paper.canvas.clientWidth;
        var dimY = paper.canvas.clientHeight;

        // set tick and tock locations


        //Draw tick/tock text


        //--------------------------------------------------
        // function to draw needle pointing to a location



         // Create the needle


        // Create a variable to keep track of the state of the needle


        // switch state of needle on click




    }

);