The Event Object

	Using event Listiners to for interaction 

   To run, go to the www directory and click on index.html
	The document should open in a browser. 

   
   