require(
        [],
        function () {

        	console.log("yo");

        }
);